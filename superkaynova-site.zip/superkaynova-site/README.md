# Superkaynova landing page: deployment guide

Static site, no build step. Files: index.html, og-image.png, robots.txt, sitemap.xml, _headers, 404.html.

## 1. Set your domain (required)
Replace the placeholder everywhere (use your real domain, with or without www, and keep it consistent):

    sed -i 's/YOURDOMAIN.com/superkaynova.com/g' index.html robots.txt sitemap.xml

Also change the contact email (hello@YOURDOMAIN.com) to a real, monitored address.

## 2. Deploy (any one of these)
- Cloudflare Pages: Create project > Direct Upload > upload this folder.
- Netlify: drag the folder onto app.netlify.com/drop.
- Vercel: `npx vercel --prod` from this folder.
Then add your custom domain in the host's dashboard, create the DNS records it shows (CNAME for www; A/ALIAS or CNAME for the root), and wait for the HTTPS certificate. Redirect the non-preferred hostname (root vs www) to the preferred one.

## 3. After launch
- Add the site to Google Search Console and submit /sitemap.xml.
- Paste GA4 / Tag Manager / pixel code at the ANALYTICS PLACEHOLDER comment in index.html. CTA clicks push `cta_click` events to window.dataLayer.
- If you add analytics or ad pixels, add a cookie-consent banner where required (EU/UK/California).
- Test the affiliate link: click each "Explore HighLevel" button and confirm it opens the HighLevel site with your fp_ref parameter.

## 4. Review before you promote it
- Privacy policy in the footer is a draft: replace with counsel-reviewed text, ideally on its own /privacy page.
- Trial and pricing wording is hedged. Third-party listings report a 14-day trial with automatic billing afterward and possible usage charges. Confirm against HighLevel's official pages and your affiliate terms (including any rules on using the HighLevel name and trademark).
- The dashboard graphic is an illustrative mockup, labeled as such. Do not add results, testimonials, earnings or discount claims unless you can substantiate them.

## 5. Known limitations / next steps
- Rendering: the page is built with React in the browser. Google can index it, but a pre-rendered build is faster and more reliable for SEO.
- Tailwind runs from its CDN script (fine for launch, not ideal for speed). For best Core Web Vitals, move to Vite + Tailwind with static CSS and pre-rendering (e.g. vite-plugin-ssr or Astro with React islands).
- Third-party scripts are version-pinned but have no Subresource Integrity hashes; add them if you self-host or after generating hashes.
- Add supporting pages for the SEO topics you target (CRM for beauty salons, appointment booking automation, HighLevel vs. other CRMs) and link them from the main page.
